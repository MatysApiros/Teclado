package Database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
	private static Connection con;

	public static Connection getConnection() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://GODTENCIPC\\SQLgutenci;" +  
         "databaseName=Agenda_Telefonica;user=gutenci;password=augustosopelsa");
			//System.out.println("Conexao ok");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return con;
	}
	
	public void listartudo() throws SQLException{
		
		PreparedStatement comando = con.prepareStatement("select * from Agenda");
		
		ResultSet rs = comando.executeQuery();
		
		while(rs.next()){
			String nome = rs.getString("Nome");
			String telefone = rs.getString("Telefone");
			
			
			//System.out.println(nome + "::" + telefone);
		}
		
		rs.close();
		con.close();
	}
	
	public void cadastraContato(String nome, String telefone) throws SQLException{
		
		PreparedStatement comando = con.prepareStatement("insert into Agenda values(?, ?)");
		
		comando.setString(1, nome);
		comando.setString(2,telefone);
		
		comando.execute();
		comando.close();
		
		con.close();
	}
	
	public void recuperaTelefone(String nome) throws SQLException{
		PreparedStatement comando = con.prepareStatement("select telefone from Agenda where Nome = '" + nome +"'");
		
		ResultSet rs = comando.executeQuery();
		
		while(rs.next()){
			String telefone = rs.getString("telefone");
			//System.out.println(telefone);
		}
		
		rs.close();
		con.close();
	}
}
