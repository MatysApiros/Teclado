package View;

public class Menu {

	public Menu() {
		// TODO Auto-generated constructor stub
	}

}
