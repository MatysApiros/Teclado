package Controler;

public class CallAgendaDAO {

	public CallAgendaDAO() {
		// TODO Auto-generated constructor stub
	}

}
