package Model;

public class Agenda {
	
	private String nome;
	private String numeroDeTelefone;
	
	public Agenda(String nome, String numeroDeTelefone) {
		this.nome = nome;
		this.numeroDeTelefone  = numeroDeTelefone;
	}
	
	public Agenda(){
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNumeroDeTelefone() {
		return numeroDeTelefone;
	}

	public void setNumeroDeTelefone(String numeroDeTelefone) {
		this.numeroDeTelefone = numeroDeTelefone;
	}
}
